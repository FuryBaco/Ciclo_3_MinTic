package com.example3.demo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
